Templates
=========

These are the basic templates we use for the creation of

* html output of cognate wordlists
* html output of multiple sequence alignments
* tex output of multiple sequence alignments

All templates contains specific keywords that the script will search for and replace with regular values. Apart from this, many aspects can be easily adjusted by modifying these templates.
