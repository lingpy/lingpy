"""
Basic module for language comparison.
"""

