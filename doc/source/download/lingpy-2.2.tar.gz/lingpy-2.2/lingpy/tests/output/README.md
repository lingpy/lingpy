Output directory for data produced by LingPy tests.
