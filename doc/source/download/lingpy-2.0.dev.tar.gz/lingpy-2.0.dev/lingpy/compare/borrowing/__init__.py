# author   : Johann-Mattis List
# email    : mattis.list@gmail.com
# created  : 2013-03-05 19:09
# modified : 2013-03-05 19:09
"""
Basic module for borrowing detection.
"""

__author__="Johann-Mattis List"
__date__="2013-03-05"

from .trebor import *

