"""
Simple py3-port of PyCogent's (http://pycogent.sourceforge.net) Tree classes.
"""
from .tree import *
