# author   : Johann-Mattis List
# email    : mattis.list@gmail.com
# created  : 2013-03-12 08:07
# modified : 2013-03-12 08:07
"""
Package provides modules for time-consuming routines.
"""

__author__="Johann-Mattis List"
__date__="2013-03-12"



